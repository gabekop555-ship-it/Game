import { useCallback, useEffect, useState } from "react";
import Game, { type RunConfig, type RunResult } from "./trash/Game";
import {
  ALL_FACES,
  DANCES,
  DIFFICULTY,
  FACES,
  LEVELS,
  rankFor,
  type DifficultyId,
  type FaceId,
} from "./trash/config";
import { Barcode, CrossMark, FaceArt, INK, RED, Smear, SpecialGlyph, Splatter, TornCard } from "./trash/art";

type Screen = "title" | "levels" | "gallery" | "game" | "result";

type Save = {
  difficulty: DifficultyId;
  unlocked: number;
  best: (number | null)[];
  ranks: (string | null)[];
  dances: number;
  finished: boolean;
};

const KEY = "trash-polka-match3-v1";

const emptySave = (): Save => ({
  difficulty: "midnight",
  unlocked: 1,
  best: LEVELS.map(() => null),
  ranks: LEVELS.map(() => null),
  dances: 0,
  finished: false,
});

function loadSave(): Save {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return emptySave();
    const p = JSON.parse(raw) as Partial<Save>;
    const base = emptySave();
    return {
      ...base,
      ...p,
      best: Array.isArray(p.best) && p.best.length === LEVELS.length ? p.best : base.best,
      ranks: Array.isArray(p.ranks) && p.ranks.length === LEVELS.length ? p.ranks : base.ranks,
    };
  } catch {
    return emptySave();
  }
}

export default function App() {
  const [save, setSave] = useState<Save>(() => loadSave());
  const [screen, setScreen] = useState<Screen>("title");
  const [config, setConfig] = useState<RunConfig | null>(null);
  const [result, setResult] = useState<RunResult | null>(null);

  const persist = useCallback((next: Save) => {
    setSave(next);
    localStorage.setItem(KEY, JSON.stringify(next));
  }, []);

  const start = useCallback(
    (index: number) => {
      setConfig({ levelIndex: index, difficulty: save.difficulty, seed: (Math.random() * 1e9) | 0 });
      setScreen("game");
    },
    [save.difficulty],
  );

  const finish = useCallback(
    (r: RunResult) => {
      setResult(r);
      setScreen("result");
      const best = [...save.best];
      const ranks = [...save.ranks];
      if (r.win && (best[r.levelIndex] == null || r.score > (best[r.levelIndex] as number))) {
        best[r.levelIndex] = r.score;
        ranks[r.levelIndex] = rankFor(r.score, LEVELS[r.levelIndex].par).tag;
      }
      persist({
        ...save,
        best,
        ranks,
        dances: save.dances + r.dances,
        unlocked: r.win ? Math.max(save.unlocked, Math.min(LEVELS.length, r.levelIndex + 2)) : save.unlocked,
        finished: save.finished || (r.win && r.levelIndex === LEVELS.length - 1),
      });
    },
    [persist, save],
  );

  if (screen === "game" && config) {
    return (
      <Game
        key={`${config.levelIndex}-${config.seed}`}
        config={config}
        onExit={() => setScreen("levels")}
        onFinish={finish}
      />
    );
  }

  return (
    <div className="app">
      <div className="paper-noise" aria-hidden="true" />
      {screen === "title" && <Title save={save} onPlay={() => start(Math.min(save.unlocked - 1, LEVELS.length - 1))} onGo={setScreen} />}
      {screen === "levels" && (
        <Levels save={save} onBack={() => setScreen("title")} onStart={start} onDiff={(d) => persist({ ...save, difficulty: d })} />
      )}
      {screen === "gallery" && <Gallery onBack={() => setScreen("title")} />}
      {screen === "result" && result && (
        <Result
          result={result}
          onRetry={() => start(result.levelIndex)}
          onNext={() => start(Math.min(LEVELS.length - 1, result.levelIndex + 1))}
          onHome={() => setScreen("levels")}
        />
      )}
    </div>
  );
}

/* ---------------------------- титул ---------------------------- */

function Title({ save, onPlay, onGo }: { save: Save; onPlay: () => void; onGo: (s: Screen) => void }) {
  const [hero, setHero] = useState<FaceId>("nosferatu");
  useEffect(() => {
    const t = window.setInterval(() => {
      setHero((h) => {
        const i = ALL_FACES.indexOf(h);
        return ALL_FACES[(i + 1) % ALL_FACES.length];
      });
    }, 1400);
    return () => window.clearInterval(t);
  }, []);

  return (
    <section className="screen title">
      <div className="t-splat a"><Splatter seed={3} opacity={0.9} /></div>
      <div className="t-splat b"><Splatter seed={11} opacity={0.5} /></div>
      <div className="t-bars"><Barcode width={140} height={26} seed={5} /></div>

      <div className="t-hero">
        <div className="t-hero-frame" key={hero}>
          <FaceArt id={hero} size={260} />
        </div>
        <span className="t-hero-name">{FACES[hero].name.toUpperCase()}</span>
      </div>

      <div className="t-body">
        <p className="kicker">три в ряд · треш-полька</p>
        <h1>
          ЛИЦА<span className="t-red">УЖАСА</span>
        </h1>
        <div className="t-smear"><Smear color={RED} /></div>
        <p className="lede">
          Красное, чёрное и рваная бумага. Складывайте по три упыря, отрывайте бонусные головы —
          а за каждую порцию очков кто-нибудь из десяти выйдет и станцует. И ни разу одинаково.
        </p>
        <div className="t-stats">
          <span><b>{save.unlocked}/{LEVELS.length}</b> катушек</span>
          <span><b>{save.dances}</b> танцев</span>
          <span><b>{DANCES.length}</b> хореографий</span>
        </div>
        <div className="row">
          <button type="button" className="btn primary big" onClick={onPlay}>
            {save.unlocked > 1 ? "ПРОДОЛЖИТЬ" : "НАЧАТЬ СЕАНС"}
          </button>
          <button type="button" className="btn" onClick={() => onGo("levels")}>Катушки</button>
          <button type="button" className="btn" onClick={() => onGo("gallery")}>Галерея</button>
        </div>
      </div>
    </section>
  );
}

/* ---------------------------- уровни ---------------------------- */

function Levels({
  save,
  onBack,
  onStart,
  onDiff,
}: {
  save: Save;
  onBack: () => void;
  onStart: (i: number) => void;
  onDiff: (d: DifficultyId) => void;
}) {
  return (
    <section className="screen sheet">
      <header className="bar">
        <button type="button" className="text-btn" onClick={onBack}>← назад</button>
        <span>катушки</span>
        <CrossMark size={18} />
      </header>
      <div className="scroll">
        <div className="lv-grid">
          {LEVELS.map((lv, i) => {
            const locked = i >= save.unlocked;
            const rank = save.ranks[i];
            return (
              <button key={lv.id} type="button" className={locked ? "lv locked" : "lv"} disabled={locked} onClick={() => onStart(i)}>
                <div className="lv-num">{String(i + 1).padStart(2, "0")}</div>
                <div className="lv-body">
                  <strong>{lv.name}</strong>
                  <em>{lv.subtitle}</em>
                  <div className="lv-faces">
                    {lv.faces.slice(0, 6).map((f) => (
                      <i key={f}><FaceArt id={f} size={26} /></i>
                    ))}
                  </div>
                  <div className="lv-meta">
                    <span>{lv.moves} ходов</span>
                    <span>
                      {lv.goal.kind === "score"
                        ? `${lv.goal.target.toLocaleString("ru-RU")} очков`
                        : lv.goal.kind === "stains"
                          ? `${lv.goal.target} пятен`
                          : "сбор голов"}
                    </span>
                    {save.best[i] != null && <span className="lv-best">рекорд {(save.best[i] as number).toLocaleString("ru-RU")}</span>}
                  </div>
                </div>
                <div className={`lv-rank ${rank ? "has" : ""}`}>{locked ? "🔒" : rank ?? "—"}</div>
              </button>
            );
          })}
        </div>

        <p className="kicker">режим</p>
        <div className="seg">
          {(Object.keys(DIFFICULTY) as DifficultyId[]).map((d) => (
            <button key={d} type="button" className={d === save.difficulty ? "on" : ""} onClick={() => onDiff(d)}>
              {DIFFICULTY[d].name}
            </button>
          ))}
        </div>
        <p className="note">
          {DIFFICULTY[save.difficulty].moveBonus > 0
            ? `+${DIFFICULTY[save.difficulty].moveBonus} ходов сверху.`
            : DIFFICULTY[save.difficulty].moveBonus < 0
              ? `${DIFFICULTY[save.difficulty].moveBonus} ходов. Для тех, кому не страшно.`
              : "Ровно столько ходов, сколько задумано."}
        </p>

        <p className="kicker">спецфигуры</p>
        <div className="sp-row">
          {(["rowBlast", "colBlast", "blot", "head"] as const).map((sp) => (
            <div key={sp} className="sp-card">
              <div className="sp-art"><SpecialGlyph kind={sp} size={64} /></div>
              <strong>
                {sp === "rowBlast" ? "Мазок вдоль" : sp === "colBlast" ? "Мазок поперёк" : sp === "blot" ? "Клякса" : "Бонусная голова"}
              </strong>
              <span>
                {sp === "rowBlast"
                  ? "четыре в строку — сносит ряд"
                  : sp === "colBlast"
                    ? "четыре в столбец — сносит столбец"
                    : sp === "blot"
                      ? "угол из пяти — выжигает 3×3"
                      : "пять в линию — стирает весь вид"}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------------------- галерея ---------------------------- */

function Gallery({ onBack }: { onBack: () => void }) {
  const [pick, setPick] = useState<FaceId>("nosferatu");
  return (
    <section className="screen sheet">
      <header className="bar">
        <button type="button" className="text-btn" onClick={onBack}>← назад</button>
        <span>галерея</span>
        <CrossMark size={18} />
      </header>
      <div className="gal-stage">
        <div className="gal-big" key={pick}>
          <TornCard tone={FACES[pick].ink === "red" ? "red" : "paper"} seed={pick.length} />
          <div className="gal-big-face"><FaceArt id={pick} size={230} /></div>
        </div>
        <div className="gal-info">
          <p className="kicker">{FACES[pick].tag}</p>
          <h2>{FACES[pick].name}</h2>
          <p className="note">{FACES[pick].lore}</p>
        </div>
      </div>
      <div className="scroll">
        <div className="gal-grid">
          {ALL_FACES.map((f) => (
            <button key={f} type="button" className={f === pick ? "gal-cell on" : "gal-cell"} onClick={() => setPick(f)}>
              <FaceArt id={f} size={54} />
              <span>{FACES[f].name}</span>
            </button>
          ))}
        </div>
        <p className="kicker">хореографии</p>
        <div className="dance-list">
          {DANCES.map((d, i) => (
            <div key={d.id} className="dance-row">
              <b>{String(i + 1).padStart(2, "0")}</b>
              <strong>{d.name}</strong>
              <em>{d.caption}</em>
            </div>
          ))}
        </div>
        <p className="note">
          Персонажи — оригинальные архетипы классических ужасов (упырь, оживлённый, мумия, оборотень и так далее),
          а не копии киногероев: те защищены авторским правом.
        </p>
      </div>
    </section>
  );
}

/* ---------------------------- результат ---------------------------- */

function Result({
  result,
  onRetry,
  onNext,
  onHome,
}: {
  result: RunResult;
  onRetry: () => void;
  onNext: () => void;
  onHome: () => void;
}) {
  const lv = LEVELS[result.levelIndex];
  const rank = rankFor(result.score, lv.par);
  const last = result.levelIndex === LEVELS.length - 1;
  return (
    <section className="screen sheet result">
      <div className="r-splat"><Splatter seed={result.score % 97} opacity={result.win ? 0.9 : 0.4} /></div>
      <div className="r-body">
        <p className="kicker">{lv.name}</p>
        <h1 className={result.win ? "win" : "lose"}>{result.win ? (last ? "КОНЕЦ ФИЛЬМА" : "КАТУШКА ОТСНЯТА") : "ПЛЁНКА ПОРВАЛАСЬ"}</h1>
        {result.win && (
          <div className="r-rank" style={{ color: rank.color }}>
            {rank.tag}
          </div>
        )}
        <div className="r-grid">
          <div><em>очки</em><strong>{result.score.toLocaleString("ru-RU")}</strong></div>
          <div><em>танцев</em><strong>{result.dances}</strong></div>
          <div><em>лучший взрыв</em><strong>{result.bestCombo}</strong></div>
          <div><em>ходов в запасе</em><strong>{result.movesLeft}</strong></div>
        </div>
        {result.win && last && <p className="note">Все катушки отсмотрены. Свет в зале так и не включили.</p>}
        {!result.win && <p className="note">Цель не закрыта. Попробуйте копить каскады: множитель растёт с каждой волной.</p>}
        <div className="row">
          {result.win && !last && <button type="button" className="btn primary big" onClick={onNext}>Следующая</button>}
          <button type="button" className="btn" onClick={onRetry}>Ещё раз</button>
          <button type="button" className="btn" onClick={onHome}>К катушкам</button>
        </div>
        <Barcode width={120} height={22} seed={result.levelIndex + 9} />
      </div>
      <div className="r-smear"><Smear color={INK} /></div>
    </section>
  );
}

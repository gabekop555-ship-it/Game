import { useCallback, useEffect, useRef, useState } from "react";
import {
  DIFFICULTY,
  FACES,
  LEVELS,
  SPECIAL_NAME,
  type DifficultyId,
  type FaceId,
  type Special,
} from "./config";
import {
  applySwap,
  areAdjacent,
  checkEnd,
  collapseClear,
  collapseFall,
  consumeDance,
  createGame,
  danceDue,
  findHint,
  goalProgress,
  grantHeads,
  hasMove,
  shuffle,
  swapIsValid,
  type Game as Sim,
  type Pos,
} from "./engine";
import Dance, { pickDance } from "./Dance";
import { Barcode, CrossMark, FaceArt, INK, RED, Smear, SpecialGlyph, Splatter, TornCard } from "./art";

export type RunConfig = { levelIndex: number; difficulty: DifficultyId; seed: number };
export type RunResult = {
  win: boolean;
  score: number;
  levelIndex: number;
  movesLeft: number;
  dances: number;
  bestCombo: number;
  stains: number;
};

type Phase = "idle" | "swap" | "clear" | "fall" | "dance" | "over";
type Ghost = { id: number; row: number; col: number; face: FaceId; special: Special };
type Pop = { id: number; row: number; col: number; text: string; kind: string };

const SWAP_MS = 190;
const CLEAR_MS = 270;
const FALL_MS = 250;

export default function Game({
  config,
  onExit,
  onFinish,
}: {
  config: RunConfig;
  onExit: () => void;
  onFinish: (r: RunResult) => void;
}) {
  const level = LEVELS[config.levelIndex];
  const simRef = useRef<Sim | null>(null);
  if (!simRef.current) simRef.current = createGame(config.levelIndex, config.difficulty, config.seed);
  const g = simRef.current;

  const phaseRef = useRef<Phase>("idle");
  const timers = useRef<number[]>([]);
  const popId = useRef(1);
  const [, setTick] = useState(0);
  const redraw = useCallback(() => setTick((t) => t + 1), []);

  const [sel, setSel] = useState<Pos | null>(null);
  const [reject, setReject] = useState<Pos[]>([]);
  const [ghosts, setGhosts] = useState<Ghost[]>([]);
  const [pops, setPops] = useState<Pop[]>([]);
  const [hint, setHint] = useState<Pos[] | null>(null);
  const [cascadeMsg, setCascadeMsg] = useState<{ n: number; id: number } | null>(null);
  const [danceState, setDanceState] = useState<{ face: FaceId; dance: ReturnType<typeof pickDance>["dance"]; heads: number } | null>(null);
  const [shuffleMsg, setShuffleMsg] = useState(false);
  const [paused, setPaused] = useState(false);
  const idleSince = useRef(Date.now());

  const after = useCallback((ms: number, fn: () => void) => {
    const t = window.setTimeout(fn, ms);
    timers.current.push(t);
    return t;
  }, []);

  useEffect(() => {
    return () => {
      timers.current.forEach((t) => window.clearTimeout(t));
      timers.current = [];
    };
  }, []);

  /* ------------------------ цикл разбора поля ------------------------ */

  const finishTurn = useCallback(() => {
    if (!hasMove(g) && g.status === "playing") {
      shuffle(g);
      setShuffleMsg(true);
      after(1500, () => setShuffleMsg(false));
    }
    checkEnd(g);
    redraw();
    if (g.status !== "playing") {
      phaseRef.current = "over";
      after(900, () =>
        onFinish({
          win: g.status === "won",
          score: g.score,
          levelIndex: config.levelIndex,
          movesLeft: Math.max(0, g.movesLeft),
          dances: g.dancesShown,
          bestCombo: g.bestCombo,
          stains: g.stainsCleared,
        }),
      );
    } else {
      phaseRef.current = "idle";
      idleSince.current = Date.now();
    }
  }, [after, config.levelIndex, g, onFinish, redraw]);

  const resolve = useCallback(() => {
    const info = collapseClear(g);
    if (info) {
      phaseRef.current = "clear";
      setGhosts(info.cleared);
      const newPops: Pop[] = [];
      const anchor = info.cleared[Math.floor(info.cleared.length / 2)];
      if (anchor) {
        newPops.push({ id: popId.current++, row: anchor.row, col: anchor.col, text: `+${info.gained}`, kind: "score" });
      }
      for (const cr of info.created) {
        newPops.push({ id: popId.current++, row: cr.row, col: cr.col, text: SPECIAL_NAME[cr.special], kind: "special" });
      }
      setPops((p) => [...p.slice(-6), ...newPops]);
      if (info.cascade >= 2) setCascadeMsg({ n: info.cascade, id: popId.current++ });
      redraw();
      after(CLEAR_MS, () => {
        setGhosts([]);
        collapseFall(g);
        phaseRef.current = "fall";
        redraw();
        after(FALL_MS, resolve);
      });
      return;
    }
    setCascadeMsg(null);
    if (danceDue(g)) {
      const heads = 3 + Math.min(2, Math.floor(g.dancesShown / 2));
      const pick = pickDance(level.faces, g.rng);
      phaseRef.current = "dance";
      setDanceState({ face: pick.face, dance: pick.dance, heads });
      redraw();
      return;
    }
    finishTurn();
  }, [after, finishTurn, g, level.faces, redraw]);

  const onDanceDone = useCallback(() => {
    const heads = danceState?.heads ?? 3;
    grantHeads(g, heads);
    consumeDance(g);
    setDanceState(null);
    redraw();
    after(120, resolve);
  }, [after, danceState, g, redraw, resolve]);

  /* ------------------------ ввод ------------------------ */

  const doSwap = useCallback(
    (a: Pos, b: Pos) => {
      if (phaseRef.current !== "idle" || g.status !== "playing" || paused) return;
      setHint(null);
      idleSince.current = Date.now();
      if (!areAdjacent(a, b)) {
        setSel(b);
        return;
      }
      if (!swapIsValid(g, a, b)) {
        setSel(null);
        setReject([a, b]);
        after(320, () => setReject([]));
        return;
      }
      setSel(null);
      const res = applySwap(g, a, b);
      if (!res.ok) return;
      phaseRef.current = "swap";
      redraw();
      after(SWAP_MS, resolve);
    },
    [after, g, paused, redraw, resolve],
  );

  const boardRef = useRef<HTMLDivElement>(null);
  const dragStart = useRef<{ pos: Pos; x: number; y: number } | null>(null);

  const cellFromEvent = useCallback(
    (e: React.PointerEvent): Pos | null => {
      const el = boardRef.current;
      if (!el) return null;
      const rect = el.getBoundingClientRect();
      const size = rect.width / g.cols;
      const col = Math.floor((e.clientX - rect.left) / size);
      const row = Math.floor((e.clientY - rect.top) / size);
      if (row < 0 || row >= g.rows || col < 0 || col >= g.cols) return null;
      return { row, col };
    },
    [g.cols, g.rows],
  );

  const onPointerDown = (e: React.PointerEvent) => {
    const p = cellFromEvent(e);
    if (!p) return;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    dragStart.current = { pos: p, x: e.clientX, y: e.clientY };
    if (sel && areAdjacent(sel, p)) doSwap(sel, p);
    else setSel(p);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    const d = dragStart.current;
    if (!d) return;
    const dx = e.clientX - d.x;
    const dy = e.clientY - d.y;
    const el = boardRef.current;
    if (!el) return;
    const size = el.getBoundingClientRect().width / g.cols;
    if (Math.hypot(dx, dy) < size * 0.45) return;
    const dir: Pos =
      Math.abs(dx) > Math.abs(dy)
        ? { row: d.pos.row, col: d.pos.col + (dx > 0 ? 1 : -1) }
        : { row: d.pos.row + (dy > 0 ? 1 : -1), col: d.pos.col };
    dragStart.current = null;
    if (dir.row < 0 || dir.row >= g.rows || dir.col < 0 || dir.col >= g.cols) return;
    doSwap(d.pos, dir);
  };

  const onPointerUp = () => {
    dragStart.current = null;
  };

  /* ------------------------ подсказка ------------------------ */

  useEffect(() => {
    const t = window.setInterval(() => {
      if (phaseRef.current !== "idle" || paused || g.status !== "playing") return;
      if (Date.now() - idleSince.current < 6000) return;
      const h = findHint(g);
      if (h) {
        setHint(h);
        window.setTimeout(() => setHint(null), 1600);
        idleSince.current = Date.now();
      }
    }, 900);
    return () => window.clearInterval(t);
  }, [g, paused]);

  useEffect(() => {
    if (!pops.length) return;
    const t = window.setTimeout(() => setPops((p) => p.slice(1)), 700);
    return () => window.clearTimeout(t);
  }, [pops]);

  /* ------------------------ отрисовка ------------------------ */

  // Map мутируется на месте, поэтому список строим на каждый кадр (64 элемента — дёшево).
  const tiles = [...g.tiles.values()];
  const progress = goalProgress(g);
  const goalPct = Math.min(100, (progress.done / progress.total) * 100);
  const cellPct = 100 / g.cols;

  const stainCells: { row: number; col: number; layers: number }[] = [];
  for (let r = 0; r < g.rows; r++)
    for (let c = 0; c < g.cols; c++) if (g.stains[r][c] > 0) stainCells.push({ row: r, col: c, layers: g.stains[r][c] });

  const style = (row: number, col: number) => ({
    left: `${col * cellPct}%`,
    top: `${row * cellPct}%`,
    width: `${cellPct}%`,
    height: `${cellPct}%`,
  });

  const isAt = (list: Pos[] | null, r: number, c: number) => !!list?.some((p) => p.row === r && p.col === c);

  return (
    <div className="game">
      <div className="paper-noise" aria-hidden="true" />

      {/* ---------- шапка ---------- */}
      <header className="g-head">
        <button type="button" className="icon-btn" onClick={() => setPaused(true)} aria-label="Пауза">‖</button>
        <div className="g-score">
          <span className="g-score-num">{g.score.toLocaleString("ru-RU")}</span>
          <span className="g-score-lbl">очки</span>
        </div>
        <div className="g-moves">
          <span className={g.movesLeft <= 3 ? "mv low" : "mv"}>{g.movesLeft}</span>
          <span className="g-score-lbl">ходов</span>
        </div>
      </header>

      {/* ---------- цель ---------- */}
      <div className="g-goal">
        <div className="g-goal-bar"><i style={{ width: `${goalPct}%` }} /></div>
        <div className="g-goal-row">
          <span className="g-goal-text">{progress.text}</span>
          <div className="g-goal-parts">
            {level.goal.kind === "collect"
              ? progress.parts.map((p) => (
                  <span key={p.label} className={p.have >= p.need ? "gp done" : "gp"}>
                    <FaceArt id={p.label as FaceId} size={22} />
                    {p.have}/{p.need}
                  </span>
                ))
              : (
                <span className={progress.done >= progress.total ? "gp done" : "gp"}>
                  {level.goal.kind === "stains" ? `${progress.done}/${progress.total}` : `${Math.floor(progress.done).toLocaleString("ru-RU")}/${progress.total.toLocaleString("ru-RU")}`}
                </span>
              )}
          </div>
        </div>
      </div>

      {/* ---------- поле ---------- */}
      <div className="board-wrap">
        <div className="board-frame">
          <div
            className="board"
            ref={boardRef}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerUp}
          >
            {/* клетки */}
            {Array.from({ length: g.rows * g.cols }, (_, i) => {
              const r = Math.floor(i / g.cols);
              const c = i % g.cols;
              return <div key={`c${i}`} className={`cell ${(r + c) % 2 ? "alt" : ""}`} style={style(r, c)} />;
            })}

            {/* пятна */}
            {stainCells.map((s) => (
              <div key={`s${s.row}-${s.col}`} className={`stain l${s.layers}`} style={style(s.row, s.col)}>
                <Splatter seed={s.row * 8 + s.col} opacity={s.layers > 1 ? 0.95 : 0.6} />
              </div>
            ))}

            {/* фигуры */}
            {tiles.map((t) => (
              <div
                key={t.id}
                className={[
                  "tile",
                  FACES[t.face].ink === "red" ? "ink-red" : "ink-black",
                  t.special !== "none" ? `sp sp-${t.special}` : "",
                  sel && sel.row === t.row && sel.col === t.col ? "selected" : "",
                  isAt(reject, t.row, t.col) ? "reject" : "",
                  isAt(hint, t.row, t.col) ? "hint" : "",
                ].join(" ")}
                style={style(t.row, t.col)}
              >
                <div className="tile-inner">
                  <TornCard tone={FACES[t.face].ink === "red" ? "red" : "paper"} seed={t.id} />
                  <div className="tile-face"><FaceArt id={t.face} size={100} /></div>
                  {t.special !== "none" && (
                    <div className="tile-special"><SpecialGlyph kind={t.special} size={100} /></div>
                  )}
                </div>
              </div>
            ))}

            {/* исчезающие фигуры */}
            {ghosts.map((t) => (
              <div key={`g${t.id}`} className="tile ghost" style={style(t.row, t.col)}>
                <div className="tile-inner">
                  <div className="tile-face"><FaceArt id={t.face} size={100} /></div>
                  <div className="ghost-splat"><Splatter seed={t.id} /></div>
                </div>
              </div>
            ))}

            {/* всплывающие очки */}
            {pops.map((p) => (
              <div key={p.id} className={`pop ${p.kind}`} style={style(p.row, p.col)}>
                <span>{p.text}</span>
              </div>
            ))}
          </div>

          <div className="frame-tape tl" />
          <div className="frame-tape br" />
        </div>

        {cascadeMsg && (
          <div className="cascade" key={cascadeMsg.id}>
            КАСКАД <b>×{cascadeMsg.n}</b>
          </div>
        )}
        {shuffleMsg && <div className="shuffle-msg">ХОДОВ НЕТ — ТАСУЕМ КОЛОДУ</div>}
      </div>

      {/* ---------- подвал ---------- */}
      <footer className="g-foot">
        <div className="foot-left">
          <span className="chip">{level.name}</span>
          <span className="chip ghosted">{DIFFICULTY[config.difficulty].name}</span>
        </div>
        <div className="foot-right">
          <span className="dance-meter">
            <b>{Math.max(0, g.danceAt - g.score).toLocaleString("ru-RU")}</b> до танца
          </span>
        </div>
      </footer>

      {danceState && (
        <Dance face={danceState.face} dance={danceState.dance} heads={danceState.heads} onDone={onDanceDone} />
      )}

      {paused && (
        <div className="overlay">
          <div className="panel">
            <div className="panel-top">
              <span className="kicker">ПАУЗА</span>
              <CrossMark size={22} />
            </div>
            <h2>{level.name}</h2>
            <p className="sub">{level.subtitle}</p>
            <div className="rules">
              <div><b>Три в ряд</b> — меняйте соседние карточки местами.</div>
              <div><b>Четыре</b> — красный мазок сносит ряд или столбец.</div>
              <div><b>Пять</b> — бонусная голова стирает все лица своего вида.</div>
              <div><b>Углом</b> — клякса выжигает квадрат 3×3.</div>
              <div><b>Танец</b> — каждые {level.danceEvery.toLocaleString("ru-RU")} очков, награда бонусными головами.</div>
            </div>
            <Smear color={INK} />
            <div className="panel-row">
              <button type="button" className="btn primary" onClick={() => setPaused(false)}>Дальше</button>
              <button type="button" className="btn" onClick={onExit}>Выйти</button>
            </div>
          </div>
        </div>
      )}

      <div className="edge-barcode"><Barcode width={86} height={18} seed={level.id + 2} /></div>
      <div className="edge-stamp">
        <span>{String(level.id + 1).padStart(2, "0")}</span>
      </div>
      <div className="corner-splat" aria-hidden="true"><Splatter seed={level.id * 5 + 2} opacity={0.14} color={RED} /></div>
    </div>
  );
}

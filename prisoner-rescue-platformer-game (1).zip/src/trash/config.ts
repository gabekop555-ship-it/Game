export type FaceId =
  | "nosferatu"
  | "stitched"
  | "mummy"
  | "wolf"
  | "witch"
  | "ghost"
  | "doll"
  | "clown"
  | "reaper"
  | "scarecrow";

export type Special = "none" | "rowBlast" | "colBlast" | "blot" | "head";

export type FaceDef = {
  id: FaceId;
  name: string;
  tag: string;
  lore: string;
  /** Доминанта карточки: красная или чёрная заливка — чтобы фигуры различались не только силуэтом. */
  ink: "black" | "red";
};

export const FACES: Record<FaceId, FaceDef> = {
  nosferatu: {
    id: "nosferatu",
    name: "Носферату",
    tag: "упырь",
    lore: "Лысый череп, уши как у нетопыря, два длинных клыка. Классика немого кошмара.",
    ink: "black",
  },
  stitched: {
    id: "stitched",
    name: "Сшитый",
    tag: "оживлённый",
    lore: "Плоский лоб, болты в шее и шов через всё лицо. Собран из того, что нашлось.",
    ink: "black",
  },
  mummy: {
    id: "mummy",
    name: "Мумия",
    tag: "бинты",
    lore: "Тысячелетние бинты и один живой глаз в прорези.",
    ink: "red",
  },
  wolf: {
    id: "wolf",
    name: "Оборотень",
    tag: "полнолуние",
    lore: "Вытянутая морда, вздыбленная шерсть, красный глаз.",
    ink: "black",
  },
  witch: {
    id: "witch",
    name: "Ведьма",
    tag: "котёл",
    lore: "Остроконечная шляпа, крючковатый нос, один зуб.",
    ink: "black",
  },
  ghost: {
    id: "ghost",
    name: "Призрак",
    tag: "простыня",
    lore: "Пустые глазницы и рот, распахнутый в беззвучном вое.",
    ink: "red",
  },
  doll: {
    id: "doll",
    name: "Кукла",
    tag: "фарфор",
    lore: "Треснувший фарфор, глаза-пуговицы, румяные щёки.",
    ink: "red",
  },
  clown: {
    id: "clown",
    name: "Клоун",
    tag: "цирк",
    lore: "Растянутая до ушей улыбка и красный нос.",
    ink: "red",
  },
  reaper: {
    id: "reaper",
    name: "Жнец",
    tag: "коса",
    lore: "Капюшон, под ним череп и два тлеющих огонька.",
    ink: "black",
  },
  scarecrow: {
    id: "scarecrow",
    name: "Пугало",
    tag: "мешковина",
    lore: "Мешок на голове, глаза-кресты, зашитый рот.",
    ink: "black",
  },
};

export const ALL_FACES: FaceId[] = [
  "nosferatu",
  "stitched",
  "mummy",
  "wolf",
  "witch",
  "ghost",
  "doll",
  "clown",
  "reaper",
  "scarecrow",
];

/* ------------------------------ танцы ------------------------------ */

export type DanceDef = {
  id: string;
  name: string;
  caption: string;
  /** Длительность одного круга хореографии, с. */
  beat: number;
};

export const DANCES: DanceDef[] = [
  { id: "coffin", name: "Гробовой шаффл", caption: "шесть покойников не дадут соврать", beat: 0.5 },
  { id: "twist", name: "Костяной твист", caption: "позвонки щёлкают в такт", beat: 0.62 },
  { id: "robot", name: "Трупное окоченение", caption: "механика вместо пластики", beat: 0.44 },
  { id: "pogo", name: "Пого на могиле", caption: "прыг-скок до самого рассвета", beat: 0.36 },
  { id: "pendulum", name: "Маятник висельника", caption: "качается, но не падает", beat: 0.9 },
  { id: "lambada", name: "Ламбада мертвеца", caption: "бёдра живут своей жизнью", beat: 0.7 },
  { id: "break", name: "Брейк на паперти", caption: "оборот вокруг оси и контрольный", beat: 0.8 },
  { id: "waltz", name: "Вальс с топором", caption: "раз-два-три, раз-два-три", beat: 1.05 },
  { id: "headbang", name: "Хэдбэнг", caption: "голова держится на одном шве", beat: 0.34 },
  { id: "marionette", name: "Марионетка", caption: "кто-то дёргает за нитки", beat: 0.56 },
];

/* ------------------------------ уровни ------------------------------ */

export type Goal =
  | { kind: "score"; target: number }
  | { kind: "collect"; faces: Partial<Record<FaceId, number>> }
  | { kind: "stains"; target: number };

export type LevelDef = {
  id: number;
  name: string;
  subtitle: string;
  moves: number;
  faces: FaceId[];
  goal: Goal;
  stains: number;
  /** Каждые N очков — танец и награда бонусными головами. */
  danceEvery: number;
  par: number;
};

export const LEVELS: LevelDef[] = [
  {
    id: 0,
    name: "Первый сеанс",
    subtitle: "плёнка рвётся, зал пустой",
    moves: 26,
    faces: ["nosferatu", "stitched", "mummy", "wolf", "witch"],
    goal: { kind: "score", target: 3500 },
    stains: 0,
    danceEvery: 1800,
    par: 17000,
  },
  {
    id: 1,
    name: "Полнолуние",
    subtitle: "кого-то в зале уже нет",
    moves: 24,
    faces: ["nosferatu", "stitched", "mummy", "wolf", "witch", "ghost"],
    goal: { kind: "collect", faces: { wolf: 14, nosferatu: 14 } },
    stains: 0,
    danceEvery: 2000,
    par: 23500,
  },
  {
    id: 2,
    name: "Пятна на плёнке",
    subtitle: "это не кетчуп",
    moves: 24,
    faces: ["mummy", "ghost", "doll", "clown", "reaper", "witch"],
    goal: { kind: "stains", target: 16 },
    stains: 16,
    danceEvery: 2200,
    par: 26000,
  },
  {
    id: 3,
    name: "Цирк уехал",
    subtitle: "клоуны остались",
    moves: 22,
    faces: ["clown", "doll", "ghost", "scarecrow", "reaper", "wolf"],
    goal: { kind: "collect", faces: { clown: 18, doll: 18 } },
    stains: 6,
    danceEvery: 2400,
    par: 22000,
  },
  {
    id: 4,
    name: "Кукольная",
    subtitle: "фарфор трескается сам",
    moves: 22,
    faces: ["doll", "scarecrow", "witch", "stitched", "mummy", "ghost", "clown"],
    goal: { kind: "score", target: 15000 },
    stains: 10,
    danceEvery: 2600,
    par: 20500,
  },
  {
    id: 5,
    name: "Поле с пугалами",
    subtitle: "они точно двигались",
    moves: 20,
    faces: ["scarecrow", "wolf", "reaper", "nosferatu", "doll", "ghost", "witch"],
    goal: { kind: "stains", target: 24 },
    stains: 24,
    danceEvery: 2800,
    par: 23000,
  },
  {
    id: 6,
    name: "Жатва",
    subtitle: "коса уже наточена",
    moves: 20,
    faces: ["reaper", "ghost", "mummy", "stitched", "clown", "scarecrow", "nosferatu"],
    goal: { kind: "collect", faces: { reaper: 20, ghost: 20 } },
    stains: 12,
    danceEvery: 3000,
    par: 26000,
  },
  {
    id: 7,
    name: "Финальные титры",
    subtitle: "все на поклон",
    moves: 20,
    faces: ["nosferatu", "stitched", "mummy", "wolf", "witch", "ghost", "doll", "clown"],
    goal: { kind: "score", target: 21000 },
    stains: 18,
    danceEvery: 3200,
    par: 23000,
  },
];

/* ------------------------------ очки ------------------------------ */

export const SCORE = {
  perTile: 60,
  specialCreate: 240,
  specialFire: 140,
  headFire: 600,
  stainClear: 120,
  movesLeft: 350,
  cascadeStep: 0.45,
};

export const BOARD = { rows: 8, cols: 8 };

export const DIFFICULTY = {
  cinema: { id: "cinema", name: "Ночной сеанс", moveBonus: 4, label: "спокойно" },
  midnight: { id: "midnight", name: "Полночь", moveBonus: 0, label: "как задумано" },
  grind: { id: "grind", name: "Мясорубка", moveBonus: -3, label: "на грани" },
};
export type DifficultyId = keyof typeof DIFFICULTY;

export function rankFor(score: number, par: number) {
  const r = score / par;
  if (r >= 1.6) return { tag: "SSS", color: "#e01a22" };
  if (r >= 1.3) return { tag: "SS", color: "#e01a22" };
  if (r >= 1.05) return { tag: "S", color: "#17151a" };
  if (r >= 0.8) return { tag: "A", color: "#17151a" };
  if (r >= 0.55) return { tag: "B", color: "#57525c" };
  return { tag: "C", color: "#57525c" };
}

export const SPECIAL_NAME: Record<Special, string> = {
  none: "",
  rowBlast: "Мазок вдоль",
  colBlast: "Мазок поперёк",
  blot: "Клякса",
  head: "Бонусная голова",
};

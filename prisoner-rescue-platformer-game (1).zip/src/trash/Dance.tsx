import { useEffect, useMemo, useRef, useState } from "react";
import { DANCES, FACES, type DanceDef, type FaceId } from "./config";
import { Barcode, CrossMark, DancerBody, FaceArt, RED, Smear, Splatter } from "./art";

let lastDanceId = "";
let lastFace: FaceId | null = null;

/** Выбирает танец и исполнителя так, чтобы они не повторяли предыдущие. */
export function pickDance(faces: FaceId[], rnd: () => number): { dance: DanceDef; face: FaceId } {
  const pool = DANCES.filter((d) => d.id !== lastDanceId);
  const dance = pool[Math.floor(rnd() * pool.length)] ?? DANCES[0];
  const facePool = faces.filter((f) => f !== lastFace);
  const face = facePool[Math.floor(rnd() * facePool.length)] ?? faces[0];
  lastDanceId = dance.id;
  lastFace = face;
  return { dance, face };
}

export default function Dance({
  face,
  dance,
  heads,
  onDone,
}: {
  face: FaceId;
  dance: DanceDef;
  heads: number;
  onDone: () => void;
}) {
  const [leaving, setLeaving] = useState(false);
  const doneRef = useRef(onDone);
  doneRef.current = onDone;

  useEffect(() => {
    const a = window.setTimeout(() => setLeaving(true), 3300);
    const b = window.setTimeout(() => doneRef.current(), 3800);
    return () => {
      window.clearTimeout(a);
      window.clearTimeout(b);
    };
  }, [face, dance.id]);

  const confetti = useMemo(
    () =>
      Array.from({ length: 22 }, (_, i) => ({
        left: (i * 37) % 100,
        delay: (i % 7) * 0.13,
        size: 6 + ((i * 13) % 16),
        red: i % 3 !== 0,
        spin: i % 2 ? 1 : -1,
      })),
    [],
  );

  const def = FACES[face];

  return (
    <div className={`dance-layer ${leaving ? "leaving" : ""}`} role="dialog" aria-label={`Танец: ${dance.name}`}>
      <div className="dance-bg" />
      <div className="dance-rays" />
      <div className="dance-splat a"><Splatter seed={7} /></div>
      <div className="dance-splat b"><Splatter seed={19} opacity={0.75} /></div>

      <div className="dance-ticker">
        <span>{dance.name.toUpperCase()} ★ {def.name.toUpperCase()} ★ БОНУСНЫЕ ГОЛОВЫ ×{heads} ★&nbsp;</span>
        <span>{dance.name.toUpperCase()} ★ {def.name.toUpperCase()} ★ БОНУСНЫЕ ГОЛОВЫ ×{heads} ★&nbsp;</span>
      </div>

      <div className={`dance-stage dc-${dance.id}`} style={{ ["--beat" as string]: `${dance.beat}s` }}>
        <div className="dancer">
          <div className="d-head">
            <FaceArt id={face} size={150} />
          </div>
          <DancerBody accent={RED} />
          <div className="d-shadow" />
        </div>
      </div>

      {confetti.map((c, i) => (
        <i
          key={i}
          className="dance-bit"
          style={{
            left: `${c.left}%`,
            width: c.size,
            height: c.size * (c.red ? 1 : 0.4),
            background: c.red ? RED : "#17151a",
            animationDelay: `${c.delay}s`,
            ["--spin" as string]: `${c.spin * 540}deg`,
          }}
        />
      ))}

      <div className="dance-card">
        <div className="dance-card-top">
          <span className="dance-kicker">ТАНЕЦ №{DANCES.findIndex((d) => d.id === dance.id) + 1}</span>
          <CrossMark size={20} />
        </div>
        <strong>{dance.name}</strong>
        <em>{dance.caption}</em>
        <div className="dance-reward">
          <span className="reward-num">+{heads}</span>
          <span className="reward-label">бонусные головы<br />падают на поле</span>
        </div>
        <Barcode width={110} height={20} seed={dance.id.length * 7 + 3} />
      </div>

      <div className="dance-smear"><Smear color={RED} /></div>
    </div>
  );
}

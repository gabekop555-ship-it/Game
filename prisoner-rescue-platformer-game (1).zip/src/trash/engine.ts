import {
  BOARD,
  DIFFICULTY,
  LEVELS,
  SCORE,
  type DifficultyId,
  type FaceId,
  type LevelDef,
  type Special,
} from "./config";

export type Tile = {
  id: number;
  face: FaceId;
  special: Special;
  row: number;
  col: number;
  born: number;
};

export type Pos = { row: number; col: number };

export type ClearInfo = {
  cleared: { id: number; row: number; col: number; face: FaceId; special: Special }[];
  created: { id: number; row: number; col: number; special: Special }[];
  stainsHit: Pos[];
  gained: number;
  cascade: number;
  biggest: number;
  usedSpecials: Special[];
};

export type Status = "playing" | "won" | "lost";

export type Game = {
  level: LevelDef;
  difficulty: DifficultyId;
  rows: number;
  cols: number;
  grid: (number | null)[][];
  tiles: Map<number, Tile>;
  stains: number[][];
  score: number;
  movesLeft: number;
  movesUsed: number;
  collected: Record<string, number>;
  stainsCleared: number;
  stainsTotal: number;
  cascade: number;
  nextId: number;
  rng: () => number;
  status: Status;
  danceAt: number;
  dancesShown: number;
  headsOwed: number;
  bestCombo: number;
  time: number;
  /** Клетки, уничтожаемые комбинацией двух спецфигур на ближайшем шаге. */
  pendingCombo?: Set<number>;
};

/* ------------------------------ утилиты ------------------------------ */

export function makeRng(seed: number) {
  let s = (seed >>> 0) || 1;
  return () => {
    s ^= s << 13;
    s >>>= 0;
    s ^= s >> 17;
    s ^= s << 5;
    s >>>= 0;
    return s / 4294967296;
  };
}

const key = (r: number, c: number) => r * 100 + c;

function inside(g: Game, r: number, c: number) {
  return r >= 0 && r < g.rows && c >= 0 && c < g.cols;
}

export function tileAt(g: Game, r: number, c: number): Tile | null {
  if (!inside(g, r, c)) return null;
  const id = g.grid[r][c];
  return id == null ? null : g.tiles.get(id) ?? null;
}

function faceAt(g: Game, r: number, c: number): FaceId | null {
  const t = tileAt(g, r, c);
  return t ? t.face : null;
}

function randomFace(g: Game): FaceId {
  const pool = g.level.faces;
  return pool[Math.floor(g.rng() * pool.length)];
}

function spawn(g: Game, r: number, c: number, face: FaceId, special: Special = "none"): Tile {
  const t: Tile = { id: g.nextId++, face, special, row: r, col: c, born: g.time };
  g.tiles.set(t.id, t);
  g.grid[r][c] = t.id;
  return t;
}

/* ------------------------------ создание ------------------------------ */

export function createGame(levelIndex: number, difficulty: DifficultyId, seed: number): Game {
  const level = LEVELS[Math.max(0, Math.min(LEVELS.length - 1, levelIndex))];
  const diff = DIFFICULTY[difficulty];
  const g: Game = {
    level,
    difficulty,
    rows: BOARD.rows,
    cols: BOARD.cols,
    grid: Array.from({ length: BOARD.rows }, () => Array<number | null>(BOARD.cols).fill(null)),
    tiles: new Map(),
    stains: Array.from({ length: BOARD.rows }, () => Array<number>(BOARD.cols).fill(0)),
    score: 0,
    movesLeft: Math.max(8, level.moves + diff.moveBonus),
    movesUsed: 0,
    collected: {},
    stainsCleared: 0,
    stainsTotal: level.stains,
    cascade: 0,
    nextId: 1,
    rng: makeRng(seed),
    status: "playing",
    // первый танец даём раньше, чтобы награду увидел даже осторожный игрок
    danceAt: Math.round(level.danceEvery * 0.5),
    dancesShown: 0,
    headsOwed: 0,
    bestCombo: 0,
    time: 0,
  };
  for (const f of level.faces) g.collected[f] = 0;

  fillBoard(g);
  placeStains(g, level.stains);
  return g;
}

function fillBoard(g: Game) {
  for (let r = 0; r < g.rows; r++) {
    for (let c = 0; c < g.cols; c++) {
      let face = randomFace(g);
      let guard = 0;
      // не даём сложиться готовой тройке при раздаче
      while (guard++ < 40 && createsImmediate(g, r, c, face)) face = randomFace(g);
      spawn(g, r, c, face);
    }
  }
  let guard = 0;
  while (!hasMove(g) && guard++ < 60) shuffle(g);
}

function createsImmediate(g: Game, r: number, c: number, face: FaceId) {
  if (faceAt(g, r, c - 1) === face && faceAt(g, r, c - 2) === face) return true;
  if (faceAt(g, r - 1, c) === face && faceAt(g, r - 2, c) === face) return true;
  return false;
}

function placeStains(g: Game, count: number) {
  let placed = 0;
  let guard = 0;
  while (placed < count && guard++ < 800) {
    const r = Math.floor(g.rng() * g.rows);
    const c = Math.floor(g.rng() * g.cols);
    if (g.stains[r][c] > 0) continue;
    // верхний ряд оставляем чистым: туда падают новые фигуры
    if (r === 0) continue;
    g.stains[r][c] = g.rng() < 0.3 ? 2 : 1;
    placed++;
  }
}

/* ------------------------------ поиск совпадений ------------------------------ */

type Group = {
  cells: Pos[];
  face: FaceId;
  maxH: number;
  maxV: number;
};

export function findGroups(g: Game): Group[] {
  const matched: boolean[][] = Array.from({ length: g.rows }, () => Array<boolean>(g.cols).fill(false));

  for (let r = 0; r < g.rows; r++) {
    let run = 1;
    for (let c = 1; c <= g.cols; c++) {
      const same = c < g.cols && faceAt(g, r, c) != null && faceAt(g, r, c) === faceAt(g, r, c - 1);
      if (same) run++;
      else {
        if (run >= 3) for (let k = c - run; k < c; k++) matched[r][k] = true;
        run = 1;
      }
    }
  }
  for (let c = 0; c < g.cols; c++) {
    let run = 1;
    for (let r = 1; r <= g.rows; r++) {
      const same = r < g.rows && faceAt(g, r, c) != null && faceAt(g, r, c) === faceAt(g, r - 1, c);
      if (same) run++;
      else {
        if (run >= 3) for (let k = r - run; k < r; k++) matched[k][c] = true;
        run = 1;
      }
    }
  }

  const seen = new Set<number>();
  const groups: Group[] = [];
  for (let r = 0; r < g.rows; r++) {
    for (let c = 0; c < g.cols; c++) {
      if (!matched[r][c] || seen.has(key(r, c))) continue;
      const face = faceAt(g, r, c);
      if (!face) continue;
      const cells: Pos[] = [];
      const stack: Pos[] = [{ row: r, col: c }];
      seen.add(key(r, c));
      while (stack.length) {
        const p = stack.pop() as Pos;
        cells.push(p);
        const around: Pos[] = [
          { row: p.row - 1, col: p.col },
          { row: p.row + 1, col: p.col },
          { row: p.row, col: p.col - 1 },
          { row: p.row, col: p.col + 1 },
        ];
        for (const n of around) {
          if (!inside(g, n.row, n.col)) continue;
          if (!matched[n.row][n.col] || seen.has(key(n.row, n.col))) continue;
          if (faceAt(g, n.row, n.col) !== face) continue;
          seen.add(key(n.row, n.col));
          stack.push(n);
        }
      }
      // длины прямых участков внутри группы
      const set = new Set(cells.map((p) => key(p.row, p.col)));
      let maxH = 1;
      let maxV = 1;
      for (const p of cells) {
        let h = 1;
        for (let k = p.col + 1; set.has(key(p.row, k)); k++) h++;
        for (let k = p.col - 1; set.has(key(p.row, k)); k--) h++;
        let v = 1;
        for (let k = p.row + 1; set.has(key(k, p.col)); k++) v++;
        for (let k = p.row - 1; set.has(key(k, p.col)); k--) v++;
        maxH = Math.max(maxH, h);
        maxV = Math.max(maxV, v);
      }
      groups.push({ cells, face, maxH, maxV });
    }
  }
  return groups;
}

function specialFor(gr: Group): Special {
  if (gr.maxH >= 5 || gr.maxV >= 5) return "head";
  if (gr.maxH >= 3 && gr.maxV >= 3) return "blot";
  if (gr.maxH === 4) return "rowBlast";
  if (gr.maxV === 4) return "colBlast";
  return "none";
}

/* ------------------------------ ходы ------------------------------ */

function swapIds(g: Game, a: Pos, b: Pos) {
  const ida = g.grid[a.row][a.col];
  const idb = g.grid[b.row][b.col];
  g.grid[a.row][a.col] = idb;
  g.grid[b.row][b.col] = ida;
  const ta = ida != null ? g.tiles.get(ida) : null;
  const tb = idb != null ? g.tiles.get(idb) : null;
  if (ta) {
    ta.row = b.row;
    ta.col = b.col;
  }
  if (tb) {
    tb.row = a.row;
    tb.col = a.col;
  }
}

export function areAdjacent(a: Pos, b: Pos) {
  return Math.abs(a.row - b.row) + Math.abs(a.col - b.col) === 1;
}

/** Даст ли обмен совпадение или срабатывание спецфигуры. */
export function swapIsValid(g: Game, a: Pos, b: Pos): boolean {
  if (!areAdjacent(a, b)) return false;
  const ta = tileAt(g, a.row, a.col);
  const tb = tileAt(g, b.row, b.col);
  if (!ta || !tb) return false;
  if (ta.special !== "none" || tb.special !== "none") return true;
  swapIds(g, a, b);
  const ok = findGroups(g).length > 0;
  swapIds(g, a, b);
  return ok;
}

export function hasMove(g: Game): boolean {
  for (let r = 0; r < g.rows; r++) {
    for (let c = 0; c < g.cols; c++) {
      if (c + 1 < g.cols && swapIsValid(g, { row: r, col: c }, { row: r, col: c + 1 })) return true;
      if (r + 1 < g.rows && swapIsValid(g, { row: r, col: c }, { row: r + 1, col: c })) return true;
    }
  }
  return false;
}

export function findHint(g: Game): [Pos, Pos] | null {
  for (let r = 0; r < g.rows; r++) {
    for (let c = 0; c < g.cols; c++) {
      const a = { row: r, col: c };
      const right = { row: r, col: c + 1 };
      const down = { row: r + 1, col: c };
      if (c + 1 < g.cols && swapIsValid(g, a, right)) return [a, right];
      if (r + 1 < g.rows && swapIsValid(g, a, down)) return [a, down];
    }
  }
  return null;
}

export function shuffle(g: Game) {
  const ids: number[] = [];
  for (let r = 0; r < g.rows; r++) for (let c = 0; c < g.cols; c++) if (g.grid[r][c] != null) ids.push(g.grid[r][c] as number);
  for (let i = ids.length - 1; i > 0; i--) {
    const j = Math.floor(g.rng() * (i + 1));
    [ids[i], ids[j]] = [ids[j], ids[i]];
  }
  let k = 0;
  for (let r = 0; r < g.rows; r++) {
    for (let c = 0; c < g.cols; c++) {
      if (g.grid[r][c] == null) continue;
      const id = ids[k++];
      g.grid[r][c] = id;
      const t = g.tiles.get(id);
      if (t) {
        t.row = r;
        t.col = c;
      }
    }
  }
  // если после перемешивания появились готовые тройки — меняем несколько фигур
  let guard = 0;
  while (findGroups(g).length > 0 && guard++ < 50) {
    const r = Math.floor(g.rng() * g.rows);
    const c = Math.floor(g.rng() * g.cols);
    const t = tileAt(g, r, c);
    if (t && t.special === "none") t.face = randomFace(g);
  }
}

/* ------------------------------ спецфигуры ------------------------------ */

function collectSpecial(g: Game, t: Tile, out: Set<number>, queue: Tile[], usedSpecials: Special[], headFace?: FaceId) {
  const push = (r: number, c: number) => {
    const n = tileAt(g, r, c);
    if (!n || out.has(n.id)) return;
    out.add(n.id);
    if (n.special !== "none") queue.push(n);
  };
  usedSpecials.push(t.special);
  if (t.special === "rowBlast") {
    for (let c = 0; c < g.cols; c++) push(t.row, c);
  } else if (t.special === "colBlast") {
    for (let r = 0; r < g.rows; r++) push(r, t.col);
  } else if (t.special === "blot") {
    for (let r = t.row - 1; r <= t.row + 1; r++) for (let c = t.col - 1; c <= t.col + 1; c++) push(r, c);
  } else if (t.special === "head") {
    const target = headFace ?? t.face;
    for (let r = 0; r < g.rows; r++) {
      for (let c = 0; c < g.cols; c++) {
        const n = tileAt(g, r, c);
        if (n && n.face === target) push(r, c);
      }
    }
  }
}

/** Комбинация двух спецфигур при прямом обмене. */
function comboClear(g: Game, ta: Tile, tb: Tile): Set<number> {
  const out = new Set<number>([ta.id, tb.id]);
  const add = (r: number, c: number) => {
    const n = tileAt(g, r, c);
    if (n) out.add(n.id);
  };
  const kinds = [ta.special, tb.special].sort().join("+");

  if (kinds === "head+head") {
    for (let r = 0; r < g.rows; r++) for (let c = 0; c < g.cols; c++) add(r, c);
  } else if (ta.special === "head" || tb.special === "head") {
    const head = ta.special === "head" ? ta : tb;
    const other = ta.special === "head" ? tb : ta;
    const target = other.face;
    for (let r = 0; r < g.rows; r++) {
      for (let c = 0; c < g.cols; c++) {
        const n = tileAt(g, r, c);
        if (!n || n.face !== target) continue;
        add(r, c);
        if (other.special === "blot") {
          for (let rr = r - 1; rr <= r + 1; rr++) for (let cc = c - 1; cc <= c + 1; cc++) add(rr, cc);
        } else if (other.special === "rowBlast") {
          for (let cc = 0; cc < g.cols; cc++) add(r, cc);
        } else if (other.special === "colBlast") {
          for (let rr = 0; rr < g.rows; rr++) add(rr, c);
        }
      }
    }
    void head;
  } else if (kinds === "blot+blot") {
    for (let r = ta.row - 2; r <= ta.row + 2; r++) for (let c = ta.col - 2; c <= ta.col + 2; c++) add(r, c);
  } else if (kinds === "blot+colBlast" || kinds === "blot+rowBlast") {
    for (let d = -1; d <= 1; d++) {
      for (let c = 0; c < g.cols; c++) add(ta.row + d, c);
      for (let r = 0; r < g.rows; r++) add(r, ta.col + d);
    }
  } else {
    for (let c = 0; c < g.cols; c++) add(ta.row, c);
    for (let r = 0; r < g.rows; r++) add(r, ta.col);
  }
  return out;
}

/* ------------------------------ ход игрока ------------------------------ */

export type SwapResult = { ok: boolean; combo?: boolean };

export function applySwap(g: Game, a: Pos, b: Pos): SwapResult {
  if (g.status !== "playing") return { ok: false };
  if (!swapIsValid(g, a, b)) return { ok: false };
  const ta = tileAt(g, a.row, a.col);
  const tb = tileAt(g, b.row, b.col);
  swapIds(g, a, b);
  g.movesLeft -= 1;
  g.movesUsed += 1;
  g.cascade = 0;
  const combo = !!(ta && tb && ta.special !== "none" && tb.special !== "none");
  if (combo && ta && tb) {
    g.pendingCombo = comboClear(g, ta, tb);
  }
  return { ok: true, combo };
}

/* ------------------------------ разбор поля ------------------------------ */

function bumpCollected(g: Game, face: FaceId) {
  g.collected[face] = (g.collected[face] ?? 0) + 1;
}

/** Один шаг «взрыва»: удаляет совпадения и спецфигуры. Возвращает null, если поле спокойно. */
export function collapseClear(g: Game): ClearInfo | null {
  const doomed = new Set<number>();
  const usedSpecials: Special[] = [];
  const created: ClearInfo["created"] = [];
  let biggest = 0;

  const pending = g.pendingCombo;
  if (pending && pending.size) {
    for (const id of pending) doomed.add(id);
    g.pendingCombo = undefined;
    biggest = pending.size;
    usedSpecials.push("head");
  } else {
    const groups = findGroups(g);
    if (!groups.length) return null;
    for (const gr of groups) {
      biggest = Math.max(biggest, gr.cells.length);
      const sp = specialFor(gr);
      let keep: Pos | null = null;
      if (sp !== "none") {
        // спецфигура рождается в середине группы
        keep = gr.cells[Math.floor(gr.cells.length / 2)];
      }
      for (const p of gr.cells) {
        if (keep && p.row === keep.row && p.col === keep.col) continue;
        const t = tileAt(g, p.row, p.col);
        if (t) doomed.add(t.id);
      }
      if (keep && sp !== "none") {
        const t = tileAt(g, keep.row, keep.col);
        if (t) {
          t.special = sp;
          created.push({ id: t.id, row: t.row, col: t.col, special: sp });
          g.score += SCORE.specialCreate;
        }
      }
    }
  }

  // цепная реакция спецфигур
  const queue: Tile[] = [];
  for (const id of doomed) {
    const t = g.tiles.get(id);
    if (t && t.special !== "none") queue.push(t);
  }
  const fired = new Set<number>();
  while (queue.length) {
    const t = queue.shift() as Tile;
    if (fired.has(t.id)) continue;
    fired.add(t.id);
    collectSpecial(g, t, doomed, queue, usedSpecials);
  }
  // созданные в этот же ход не взрываются сразу
  for (const c of created) doomed.delete(c.id);

  if (!doomed.size) return null;

  const cleared: ClearInfo["cleared"] = [];
  const stainsHit: Pos[] = [];
  for (const id of doomed) {
    const t = g.tiles.get(id);
    if (!t) continue;
    cleared.push({ id: t.id, row: t.row, col: t.col, face: t.face, special: t.special });
    bumpCollected(g, t.face);
    if (g.stains[t.row][t.col] > 0) {
      g.stains[t.row][t.col] -= 1;
      g.stainsCleared += 1;
      stainsHit.push({ row: t.row, col: t.col });
      g.score += SCORE.stainClear;
    }
    g.grid[t.row][t.col] = null;
    g.tiles.delete(id);
  }

  const mult = 1 + g.cascade * SCORE.cascadeStep;
  let gained = Math.round(cleared.length * SCORE.perTile * mult);
  for (const sp of usedSpecials) gained += sp === "head" ? SCORE.headFire : SCORE.specialFire;
  g.score += gained;
  g.bestCombo = Math.max(g.bestCombo, cleared.length);
  g.cascade += 1;

  return { cleared, created, stainsHit, gained, cascade: g.cascade, biggest, usedSpecials };
}

/** Падение и добор новых фигур. */
export function collapseFall(g: Game): { moved: number[]; spawned: number[] } {
  const moved: number[] = [];
  const spawned: number[] = [];
  for (let c = 0; c < g.cols; c++) {
    let write = g.rows - 1;
    for (let r = g.rows - 1; r >= 0; r--) {
      const id = g.grid[r][c];
      if (id == null) continue;
      if (r !== write) {
        g.grid[write][c] = id;
        g.grid[r][c] = null;
        const t = g.tiles.get(id);
        if (t) {
          t.row = write;
          moved.push(id);
        }
      }
      write--;
    }
    for (let r = write; r >= 0; r--) {
      const t = spawn(g, r, c, randomFace(g));
      spawned.push(t.id);
    }
  }
  return { moved, spawned };
}

/** Награда за танец: несколько случайных фигур становятся бонусными головами. */
export function grantHeads(g: Game, n: number): number[] {
  const out: number[] = [];
  const candidates: Tile[] = [];
  for (let r = 0; r < g.rows; r++) {
    for (let c = 0; c < g.cols; c++) {
      const t = tileAt(g, r, c);
      if (t && t.special === "none") candidates.push(t);
    }
  }
  for (let i = candidates.length - 1; i > 0; i--) {
    const j = Math.floor(g.rng() * (i + 1));
    [candidates[i], candidates[j]] = [candidates[j], candidates[i]];
  }
  for (let i = 0; i < Math.min(n, candidates.length); i++) {
    candidates[i].special = "head";
    out.push(candidates[i].id);
  }
  return out;
}

/* ------------------------------ цели и финал ------------------------------ */

export function goalProgress(g: Game): { done: number; total: number; text: string; parts: { label: string; have: number; need: number }[] } {
  const goal = g.level.goal;
  if (goal.kind === "score") {
    return {
      done: Math.min(g.score, goal.target),
      total: goal.target,
      text: `Набрать ${goal.target.toLocaleString("ru-RU")}`,
      parts: [{ label: "очки", have: Math.min(g.score, goal.target), need: goal.target }],
    };
  }
  if (goal.kind === "stains") {
    return {
      done: Math.min(g.stainsCleared, goal.target),
      total: goal.target,
      text: `Оттереть ${goal.target} пятен`,
      parts: [{ label: "пятна", have: Math.min(g.stainsCleared, goal.target), need: goal.target }],
    };
  }
  const parts = Object.entries(goal.faces).map(([f, need]) => ({
    label: f,
    have: Math.min(g.collected[f] ?? 0, need as number),
    need: need as number,
  }));
  const done = parts.reduce((s, p) => s + p.have, 0);
  const total = parts.reduce((s, p) => s + p.need, 0);
  return { done, total, text: "Собрать головы", parts };
}

export function goalMet(g: Game): boolean {
  const p = goalProgress(g);
  return p.done >= p.total;
}

export function checkEnd(g: Game) {
  if (g.status !== "playing") return;
  if (goalMet(g)) {
    g.status = "won";
    g.score += Math.max(0, g.movesLeft) * SCORE.movesLeft;
  } else if (g.movesLeft <= 0) {
    g.status = "lost";
  }
}

/** Нужен ли танец прямо сейчас. */
export function danceDue(g: Game): boolean {
  return g.status === "playing" && g.score >= g.danceAt;
}

export function consumeDance(g: Game) {
  g.danceAt += g.level.danceEvery;
  g.dancesShown += 1;
  while (g.score >= g.danceAt) g.danceAt += g.level.danceEvery;
}

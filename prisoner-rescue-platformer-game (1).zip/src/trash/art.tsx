import type { FaceId, Special } from "./config";

export const INK = "#17151a";
export const INK2 = "#2b262e";
export const RED = "#c8161d";
export const RED_D = "#8a0e13";
export const RED_L = "#e8262e";
export const BONE = "#efe9df";
export const PAPER = "#e3dbcf";

/* =======================================================================
   ЛИЦА. Виньетка 100×100. Только чёрный, красный и костяной —
   канон треш-польки: жирный силуэт + рваный красный акцент.
   ======================================================================= */

function Nosferatu() {
  return (
    <g>
      <path d="M50 88c-16 0-25-13-26-30-1-9 1-18 4-24l-9-18c-1-3 2-5 4-3l14 12c4-3 8-4 13-4s9 1 13 4l14-12c2-2 5 0 4 3l-9 18c3 6 5 15 4 24-1 17-10 30-26 30z" fill={INK} />
      <path d="M22 13l11 10-4 8-8-15z" fill={INK} />
      <path d="M78 13L67 23l4 8 8-15z" fill={INK} />
      <ellipse cx="38" cy="44" rx="8" ry="10" fill={BONE} />
      <ellipse cx="62" cy="44" rx="8" ry="10" fill={BONE} />
      <ellipse cx="39" cy="46" rx="4.4" ry="5.6" fill={INK} />
      <ellipse cx="61" cy="46" rx="4.4" ry="5.6" fill={INK} />
      <path d="M50 50l-5 12h10z" fill={BONE} opacity="0.9" />
      <path d="M36 70c6 3 22 3 28 0-4 6-24 6-28 0z" fill={BONE} />
      <path d="M42 71l2.5 9 2.5-9zM53 71l2.5 9 2.5-9z" fill={BONE} />
      <path d="M30 30c4-3 9-4 12-3M70 30c-4-3-9-4-12-3" stroke={BONE} strokeWidth="2" fill="none" strokeLinecap="round" opacity="0.5" />
      <path d="M51 80c-1 5-4 8-3 12 1 3 5 3 6 0 1-4-2-7-3-12z" fill={RED} />
      <circle cx="56" cy="95" r="2.4" fill={RED} />
    </g>
  );
}

function Stitched() {
  return (
    <g>
      <path d="M24 34h52v40c0 9-11 15-26 15s-26-6-26-15z" fill={INK} />
      <path d="M22 18h56v18H22z" fill={INK} />
      <path d="M20 16h60v7H20z" fill={INK2} />
      <rect x="10" y="52" width="10" height="9" rx="2" fill={INK} />
      <rect x="80" y="52" width="10" height="9" rx="2" fill={INK} />
      <rect x="7" y="54" width="5" height="5" fill={INK2} />
      <rect x="88" y="54" width="5" height="5" fill={INK2} />
      <rect x="31" y="44" width="15" height="8" fill={BONE} />
      <rect x="54" y="44" width="15" height="8" fill={BONE} />
      <rect x="35" y="45.5" width="6" height="5.5" fill={INK} />
      <rect x="58" y="45.5" width="6" height="5.5" fill={INK} />
      <path d="M26 40h48" stroke={BONE} strokeWidth="2" opacity="0.35" />
      <path d="M36 70h28" stroke={BONE} strokeWidth="3" strokeLinecap="round" />
      <path d="M40 66v8M46 66v8M52 66v8M58 66v8" stroke={BONE} strokeWidth="2" />
      <path d="M22 30h56" stroke={RED} strokeWidth="3.4" />
      <path d="M26 26l4 8M34 26l4 8M42 26l4 8M50 26l4 8M58 26l4 8M66 26l4 8" stroke={RED} strokeWidth="2.2" strokeLinecap="round" />
      <path d="M70 56c3 6 3 12 1 17" stroke={RED} strokeWidth="2" fill="none" strokeLinecap="round" />
    </g>
  );
}

function Mummy() {
  return (
    <g>
      <path d="M50 10c17 0 27 13 27 33s-10 45-27 45S23 63 23 43 33 10 50 10z" fill={BONE} />
      <path d="M23 26h54M21 36l58-4M22 47h56M24 58l53 3M27 69l47-5M31 79l38 4" stroke={INK} strokeWidth="2.6" strokeLinecap="round" opacity="0.85" />
      <path d="M26 20c10-7 38-7 48 0" stroke={INK} strokeWidth="2.6" fill="none" strokeLinecap="round" opacity="0.85" />
      <path d="M30 40h40v13H30z" fill={INK} />
      <ellipse cx="60" cy="46.5" rx="6" ry="5" fill={RED} />
      <circle cx="60" cy="46.5" r="2.4" fill={INK} />
      <path d="M36 44l8 5-8 4z" fill={BONE} opacity="0.6" />
      <path d="M74 62c7 4 11 12 8 20-2 6-8 7-10 2" fill={RED} opacity="0.92" />
      <path d="M40 88c6 3 16 3 22 0" stroke={INK} strokeWidth="2.4" fill="none" strokeLinecap="round" />
      <path d="M22 47c-8 2-13 8-12 15 1 5 6 6 8 2" fill={BONE} stroke={INK} strokeWidth="2" />
      <circle cx="35" cy="66" r="3" fill={RED} opacity="0.8" />
    </g>
  );
}

function Wolf() {
  return (
    <g>
      <path d="M18 24l6 20 10-8zM82 24l-6 20-10-8z" fill={INK} />
      <path d="M50 16c14 0 24 9 26 22 2 11-1 20-6 26l-9 10c-3 4-7 6-11 6s-8-2-11-6l-9-10c-5-6-8-15-6-26 2-13 12-22 26-22z" fill={INK} />
      <path d="M14 38l10 6-8 6zM86 38l-10 6 8 6z" fill={INK} />
      <path d="M43 62h14l6 12c1 3-1 6-4 6H41c-3 0-5-3-4-6z" fill={INK2} />
      <path d="M40 74h20l-2 5H42z" fill={BONE} />
      <path d="M42 74l2 5 2-5zM54 74l2 5 2-5zM47 74l1.6 4 1.6-4zM50.8 74l1.6 4 1.6-4z" fill={BONE} />
      <path d="M40 78c5 4 15 4 20 0-2 6-18 6-20 0z" fill={RED} />
      <ellipse cx="50" cy="65" rx="5" ry="3.6" fill={INK} />
      <path d="M31 42l13 4-13 5z" fill={RED} />
      <path d="M69 42l-13 4 13 5z" fill={BONE} />
      <path d="M36 28c4-2 8-2 11 0M64 28c-4-2-8-2-11 0" stroke={BONE} strokeWidth="2.4" fill="none" strokeLinecap="round" opacity="0.6" />
      <path d="M22 60c-6 5-8 12-5 18" stroke={INK} strokeWidth="2.6" fill="none" strokeLinecap="round" />
      <path d="M78 60c6 5 8 12 5 18" stroke={INK} strokeWidth="2.6" fill="none" strokeLinecap="round" />
    </g>
  );
}

function Witch() {
  return (
    <g>
      <path d="M50 4c4 0 6 3 8 8l14 30H28l14-30c2-5 4-8 8-8z" fill={INK} />
      <path d="M46 6c-6 6-10 18-12 26l-6 10 22-6z" fill={INK2} />
      <path d="M22 40h56c3 0 5 2 5 4s-2 4-5 4H22c-3 0-5-2-5-4s2-4 5-4z" fill={INK} />
      <path d="M22 41h56v3H22z" fill={RED} />
      <path d="M32 48c2 16 7 28 18 34 11-6 16-18 18-34z" fill={BONE} />
      <path d="M34 48c-6 10-8 22-6 32M66 48c6 10 8 22 6 32" stroke={INK} strokeWidth="3" fill="none" strokeLinecap="round" />
      <ellipse cx="41" cy="58" rx="4.4" ry="3.6" fill={INK} />
      <ellipse cx="59" cy="58" rx="4.4" ry="3.6" fill={INK} />
      <path d="M36 52c3-2 6-2 8-1M64 52c-3-2-6-2-8-1" stroke={INK} strokeWidth="2" fill="none" strokeLinecap="round" />
      <path d="M50 58l-8 14c3 2 8 1 10-2z" fill={BONE} stroke={INK} strokeWidth="2" strokeLinejoin="round" />
      <circle cx="44" cy="70" r="2.2" fill={INK} />
      <path d="M42 78c5 3 11 3 16 0-1 5-15 5-16 0z" fill={INK} />
      <path d="M48 78v4.5h3V78z" fill={BONE} />
      <path d="M72 14c3 4 4 9 3 13" stroke={RED} strokeWidth="2.6" fill="none" strokeLinecap="round" />
    </g>
  );
}

function Ghost() {
  return (
    <g>
      <path d="M50 8c19 0 30 14 30 34v42l-9-8-8 8-7-8-6 8-6-8-7 8-8-8-9 8V42C20 22 31 8 50 8z" fill={BONE} />
      <ellipse cx="38" cy="42" rx="9" ry="12" fill={INK} />
      <ellipse cx="62" cy="42" rx="9" ry="12" fill={INK} />
      <ellipse cx="50" cy="68" rx="10" ry="14" fill={INK} />
      <path d="M31 25c5-4 10-5 14-4M69 25c-5-4-10-5-14-4" stroke={INK} strokeWidth="2.4" fill="none" strokeLinecap="round" opacity="0.4" />
      <path d="M22 50c-2 10-1 20 2 27" stroke={INK} strokeWidth="2" fill="none" opacity="0.3" />
      <path d="M78 50c2 10 1 20-2 27" stroke={INK} strokeWidth="2" fill="none" opacity="0.3" />
      <path d="M50 54c-4 4-6 9-6 14 0 8 4 14 6 14s6-6 6-14c0-5-2-10-6-14z" fill={INK} />
      <path d="M62 16c8 6 12 15 12 26" stroke={RED} strokeWidth="3" fill="none" strokeLinecap="round" />
      <circle cx="74" cy="52" r="3.4" fill={RED} />
      <circle cx="28" cy="62" r="2.4" fill={RED} />
    </g>
  );
}

function Doll() {
  return (
    <g>
      <path d="M50 12c21 0 34 15 34 36S71 88 50 88 16 69 16 48s13-36 34-36z" fill={BONE} />
      <path d="M50 12c-16 0-27 9-32 22 8-6 20-9 32-9s24 3 32 9c-5-13-16-22-32-22z" fill={INK} />
      <path d="M18 34c-4 10-3 22 2 30L16 46z" fill={INK} />
      <path d="M82 34c4 10 3 22-2 30l4-18z" fill={INK} />
      <circle cx="38" cy="48" r="8" fill={INK} />
      <circle cx="62" cy="48" r="8" fill={INK} />
      <circle cx="38" cy="48" r="3" fill={BONE} />
      <circle cx="62" cy="48" r="3" fill={BONE} />
      <path d="M34 44l8 8M42 44l-8 8M58 44l8 8M66 44l-8 8" stroke={BONE} strokeWidth="1.6" opacity="0.7" />
      <circle cx="28" cy="62" r="7" fill={RED} opacity="0.9" />
      <circle cx="72" cy="62" r="7" fill={RED} opacity="0.9" />
      <path d="M45 68c3 3 7 3 10 0-1 5-9 5-10 0z" fill={RED} />
      <path d="M62 20l-6 16 8 10-5 14 7 12" stroke={INK} strokeWidth="2.2" fill="none" strokeLinecap="round" />
      <path d="M40 26l3 10-5 6" stroke={INK} strokeWidth="1.8" fill="none" strokeLinecap="round" />
      <path d="M50 78c-2 6-1 10 1 14" stroke={RED} strokeWidth="2.4" fill="none" strokeLinecap="round" />
    </g>
  );
}

function Clown() {
  return (
    <g>
      <path d="M50 14c18 0 29 13 29 32S68 86 50 86 21 65 21 46s11-32 29-32z" fill={BONE} />
      <path d="M14 30c-4 8-3 18 2 26 4 6 8 4 7-3-1-8 0-15 3-21z" fill={RED} />
      <path d="M86 30c4 8 3 18-2 26-4 6-8 4-7-3 1-8 0-15-3-21z" fill={RED} />
      <path d="M22 34c6-12 16-20 28-20s22 8 28 20c-8-6-17-9-28-9s-20 3-28 9z" fill={RED} />
      <path d="M33 40l14 6-14 6z" fill={INK} />
      <path d="M67 40L53 46l14 6z" fill={INK} />
      <path d="M30 38l6 4M70 38l-6 4" stroke={INK} strokeWidth="2.4" strokeLinecap="round" />
      <circle cx="50" cy="56" r="8" fill={RED} />
      <circle cx="47" cy="53" r="2.6" fill={RED_L} />
      <path d="M26 62c6 14 14 21 24 21s18-7 24-21c-6 5-14 8-24 8s-18-3-24-8z" fill={RED} />
      <path d="M30 66c5 3 12 5 20 5s15-2 20-5c-2 3-4 6-6 8H36c-2-2-4-5-6-8z" fill={BONE} />
      <path d="M40 66v9M50 67v10M60 66v9" stroke={INK} strokeWidth="1.8" />
      <path d="M22 60l-6-3M78 60l6-3" stroke={INK} strokeWidth="2.4" strokeLinecap="round" />
    </g>
  );
}

function Reaper() {
  return (
    <g>
      <path d="M50 6c22 0 34 16 34 40 0 20-6 34-14 42H30c-8-8-14-22-14-42C16 22 28 6 50 6z" fill={INK} />
      <path d="M50 22c13 0 21 10 21 24 0 11-4 19-9 24H38c-5-5-9-13-9-24 0-14 8-24 21-24z" fill={INK2} />
      <path d="M50 28c11 0 18 9 18 21 0 8-3 15-7 19H39c-4-4-7-11-7-19 0-12 7-21 18-21z" fill={BONE} />
      <ellipse cx="41" cy="48" rx="6.5" ry="8" fill={INK} />
      <ellipse cx="59" cy="48" rx="6.5" ry="8" fill={INK} />
      <circle cx="41" cy="49" r="3.4" fill={RED} />
      <circle cx="59" cy="49" r="3.4" fill={RED} />
      <path d="M50 56l-4 8h8z" fill={INK} />
      <path d="M40 70h20v4H40z" fill={INK} />
      <path d="M44 70v4M48 70v4M52 70v4M56 70v4" stroke={BONE} strokeWidth="1.4" />
      <path d="M16 46c-4 12-3 26 3 36M84 46c4 12 3 26-3 36" stroke={INK} strokeWidth="4" fill="none" strokeLinecap="round" />
      <path d="M22 12c8-6 18-8 28-8s20 2 28 8" stroke={RED} strokeWidth="3" fill="none" strokeLinecap="round" opacity="0.9" />
      <circle cx="78" cy="22" r="3" fill={RED} />
    </g>
  );
}

function Scarecrow() {
  return (
    <g>
      <path d="M50 12c18 0 30 12 30 32s-12 42-30 42S20 64 20 44s12-32 30-32z" fill={BONE} />
      <path d="M20 44c0-20 12-32 30-32v74C32 86 20 64 20 44z" fill={PAPER} />
      <path d="M50 12v74" stroke={INK} strokeWidth="2" opacity="0.35" />
      <path d="M32 40l12 12M44 40L32 52M56 40l12 12M68 40L56 52" stroke={INK} strokeWidth="4.4" strokeLinecap="round" />
      <path d="M34 68h32" stroke={INK} strokeWidth="3.4" strokeLinecap="round" />
      <path d="M36 63v10M43 63v10M50 63v10M57 63v10M64 63v10" stroke={INK} strokeWidth="2.6" strokeLinecap="round" />
      <path d="M18 18l14 10-4 6zM82 18L68 28l4 6z" fill={INK} />
      <path d="M22 26c-6-4-10-10-10-16 5 5 10 8 14 9zM78 26c6-4 10-10 10-16-5 5-10 8-14 9z" fill={INK} opacity="0.85" />
      <path d="M12 52l12 4-12 6zM88 52l-12 4 12 6z" fill={INK} opacity="0.8" />
      <path d="M58 20h18v14H58z" fill={RED} />
      <path d="M58 20l18 14M76 20L58 34" stroke={BONE} strokeWidth="1.8" opacity="0.6" />
      <path d="M26 78c8 5 20 6 30 3" stroke={INK} strokeWidth="2.4" fill="none" strokeLinecap="round" opacity="0.6" />
    </g>
  );
}

const FACE_ART: Record<FaceId, () => React.ReactElement> = {
  nosferatu: Nosferatu,
  stitched: Stitched,
  mummy: Mummy,
  wolf: Wolf,
  witch: Witch,
  ghost: Ghost,
  doll: Doll,
  clown: Clown,
  reaper: Reaper,
  scarecrow: Scarecrow,
};

/** Только лицо, без подложки — для танца и карточек. */
export function FaceArt({ id, size = 100 }: { id: FaceId; size?: number }) {
  const Art = FACE_ART[id];
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className="face-svg">
      <Art />
    </svg>
  );
}

/* =======================================================================
   ЭЛЕМЕНТЫ КОЛЛАЖА
   ======================================================================= */

export function Splatter({ seed = 1, color = RED, opacity = 1 }: { seed?: number; color?: string; opacity?: number }) {
  const r = (n: number) => {
    const x = Math.sin(seed * 999 + n * 77.7) * 10000;
    return x - Math.floor(x);
  };
  const drops = Array.from({ length: 11 }, (_, i) => ({
    cx: 10 + r(i) * 80,
    cy: 10 + r(i + 20) * 80,
    rr: 1 + r(i + 40) * 7,
  }));
  return (
    <svg viewBox="0 0 100 100" className="splatter" style={{ opacity }} aria-hidden="true">
      <path d="M50 18c14-6 30 2 32 16 2 13-8 20-4 30 4 11-8 22-22 20-12-2-16-10-28-10-13 0-22-10-19-22 3-11 14-12 20-20 5-7 10-11 21-14z" fill={color} opacity="0.9" />
      {drops.map((d, i) => (
        <circle key={i} cx={d.cx} cy={d.cy} r={d.rr} fill={color} />
      ))}
    </svg>
  );
}

export function Smear({ color = INK, className = "" }: { color?: string; className?: string }) {
  return (
    <svg viewBox="0 0 200 40" className={`smear ${className}`} preserveAspectRatio="none" aria-hidden="true">
      <path d="M2 22c18-10 34 4 52-2s30-14 50-10 30 16 48 10 30-12 46-6v18c-16-4-28 6-44 10s-32-6-50-2-28 12-46 8-26-14-42-10-12 6-14 6z" fill={color} />
    </svg>
  );
}

export function CrossMark({ color = RED, size = 28 }: { color?: string; size?: number }) {
  return (
    <svg viewBox="0 0 40 40" width={size} height={size} aria-hidden="true">
      <path d="M6 4l30 28-4 4L2 8z" fill={color} />
      <path d="M34 4L4 32l4 4L38 8z" fill={color} />
    </svg>
  );
}

export function Barcode({ width = 90, height = 26, seed = 3 }: { width?: number; height?: number; seed?: number }) {
  const bars: { x: number; w: number }[] = [];
  let x = 0;
  let s = seed;
  while (x < 100) {
    s = (s * 16807) % 2147483647;
    const w = 0.8 + ((s / 2147483647) * 3);
    bars.push({ x, w });
    x += w + 1.2 + (s % 3) * 0.4;
  }
  return (
    <svg viewBox="0 0 100 30" width={width} height={height} aria-hidden="true">
      {bars.map((b, i) => (
        <rect key={i} x={b.x} y="0" width={b.w} height="24" fill={INK} />
      ))}
    </svg>
  );
}

export function SpecialGlyph({ kind, size = 100 }: { kind: Special; size?: number }) {
  if (kind === "none") return null;
  if (kind === "rowBlast") {
    return (
      <svg viewBox="0 0 100 100" width={size} height={size} className="glyph" aria-hidden="true">
        <path d="M4 42c20-8 34 6 52 0s28-10 42-4v22c-16-6-28 6-46 10s-30-8-48-2z" fill={RED} opacity="0.92" />
        <path d="M78 36l18 14-18 14z" fill={INK} />
      </svg>
    );
  }
  if (kind === "colBlast") {
    return (
      <svg viewBox="0 0 100 100" width={size} height={size} className="glyph" aria-hidden="true">
        <path d="M42 4c8 20-6 34 0 52s10 28 4 42H24c6-16-6-28-10-46s8-30 2-48z" fill={RED} opacity="0.92" transform="translate(17 0)" />
        <path d="M36 78l14 18 14-18z" fill={INK} />
      </svg>
    );
  }
  if (kind === "blot") {
    return (
      <svg viewBox="0 0 100 100" width={size} height={size} className="glyph" aria-hidden="true">
        <path d="M50 10c16 0 22 12 30 20s14 22 6 34-24 8-36 12-26 2-32-10 2-22 4-34 12-22 28-22z" fill={INK} />
        <circle cx="26" cy="24" r="5" fill={INK} />
        <circle cx="80" cy="72" r="6" fill={INK} />
        <circle cx="50" cy="48" r="12" fill={RED} />
        <path d="M50 30v36M32 48h36" stroke={BONE} strokeWidth="4" strokeLinecap="round" />
      </svg>
    );
  }
  return null;
}

/** Рваная бумажная подложка карточки. */
export function TornCard({ tone = "paper", seed = 1 }: { tone?: "paper" | "red" | "ink"; seed?: number }) {
  const fill = tone === "red" ? RED : tone === "ink" ? INK : PAPER;
  const o = (n: number) => {
    const x = Math.sin(seed * 411 + n * 31.3) * 10000;
    return (x - Math.floor(x)) * 3 - 1.5;
  };
  const d = `M${2 + o(1)} ${4 + o(2)}
    L${50 + o(3)} ${1 + o(4)} L${98 + o(5)} ${4 + o(6)}
    L${99 + o(7)} ${50 + o(8)} L${97 + o(9)} ${96 + o(10)}
    L${50 + o(11)} ${99 + o(12)} L${3 + o(13)} ${97 + o(14)}
    L${1 + o(15)} ${50 + o(16)} Z`;
  return (
    <svg viewBox="0 0 100 100" className="torn" preserveAspectRatio="none" aria-hidden="true">
      <path d={d} fill={fill} />
    </svg>
  );
}

/** Силуэт тела для танцующего персонажа — рубленые чернильные формы. */
export function DancerBody({ accent = RED }: { accent?: string }) {
  return (
    <>
      <svg viewBox="0 0 100 120" className="d-torso" aria-hidden="true">
        <path d="M26 6h48l8 40-10 62H28L18 46z" fill={INK} />
        <path d="M34 14h32l5 28-7 46H36l-7-46z" fill={INK2} />
        <path d="M30 52h40l-3 14H33z" fill={accent} />
        <path d="M44 20l12 10-12 10" stroke={BONE} strokeWidth="3" fill="none" strokeLinecap="round" opacity="0.5" />
      </svg>
      <svg viewBox="0 0 40 110" className="d-arm d-arm-l" aria-hidden="true">
        <path d="M12 4h16v58l6 42-14 4-12-46z" fill={INK} />
        <circle cx="22" cy="104" r="9" fill={INK} />
        <path d="M14 60h14l2 10H16z" fill={accent} />
      </svg>
      <svg viewBox="0 0 40 110" className="d-arm d-arm-r" aria-hidden="true">
        <path d="M12 4h16v58l6 42-14 4-12-46z" fill={INK} />
        <circle cx="22" cy="104" r="9" fill={INK} />
        <path d="M14 60h14l2 10H16z" fill={accent} />
      </svg>
      <svg viewBox="0 0 44 120" className="d-leg d-leg-l" aria-hidden="true">
        <path d="M10 2h24v56l4 50H14L8 58z" fill={INK} />
        <path d="M6 104h32l4 14H2z" fill={INK} />
        <path d="M8 108h28v4H8z" fill={accent} />
      </svg>
      <svg viewBox="0 0 44 120" className="d-leg d-leg-r" aria-hidden="true">
        <path d="M10 2h24v56l4 50H14L8 58z" fill={INK} />
        <path d="M6 104h32l4 14H2z" fill={INK} />
        <path d="M8 108h28v4H8z" fill={accent} />
      </svg>
    </>
  );
}
